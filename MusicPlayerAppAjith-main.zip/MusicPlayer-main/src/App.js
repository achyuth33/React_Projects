import MainPage from "./components/mainPage";
import "./App.css";

const App = () => {
  return <MainPage />;
};

export default App;
